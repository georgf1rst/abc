const AnalyticsPage = () => {
    return ( 
        <div>
            AnalyticsPage
        </div>
     );
}
 
export default AnalyticsPage;