const SearchPage = () => {
    return ( 
        <div>
            Search page
        </div>
     );
}
 
export default SearchPage;